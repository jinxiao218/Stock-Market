package com.ibm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "STOCK_EXCHANGE")
public class StockExchange {
	@Id
	@GeneratedValue
	@Column(name="id")
	private long id;
	
	@Column(name="code", nullable = false)
	private String code;
	
	@Column(name="brief", nullable = false)
	private String brief;
	
	@Column(name="address", nullable = false)
	private String address;
	
	@Column(name="remarks", nullable = false)
	private String remarks;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getBrief() {
		return brief;
	}

	public void setBrief(String brief) {
		this.brief = brief;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
}
