import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-export2excel',
  templateUrl: './export2excel.component.html',
  styleUrls: ['./export2excel.component.css']
})
export class Export2excelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
