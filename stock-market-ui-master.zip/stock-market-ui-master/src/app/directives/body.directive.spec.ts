import { BodyDirective } from './body.directive';

describe('BodyDirective', () => {
  it('should create an instance', () => {
    const directive = new BodyDirective();
    expect(directive).toBeTruthy();
  });
});
