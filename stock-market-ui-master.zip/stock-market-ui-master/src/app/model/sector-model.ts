export interface SectorModel {
    id: number
    name: string
}
