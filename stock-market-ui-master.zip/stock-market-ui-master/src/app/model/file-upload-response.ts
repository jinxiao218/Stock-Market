export interface FileUploadResponse {
    success: boolean,
    message: string
}
