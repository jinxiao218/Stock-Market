export interface ExchangeModel {
    id: number
    code: string
    brief: string
    address: string
    remarks: string
}
