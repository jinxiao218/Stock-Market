export class User {
    username: String;
    userType?: number;
    token?: String; 
}
