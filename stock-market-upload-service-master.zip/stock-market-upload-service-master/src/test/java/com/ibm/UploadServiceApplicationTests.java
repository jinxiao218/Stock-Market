package com.ibm;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UploadServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
