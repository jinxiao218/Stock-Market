package com.ibm.service;

import com.ibm.model.FileRecord;

public interface FileProcessingService {

	public void processFile(FileRecord record);
	
}
