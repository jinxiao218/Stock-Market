import { ErrorInterceptor } from './error-interceptor';

describe('ErrorInterceptor', () => {
  it('should create an instance', () => {
    expect(new ErrorInterceptor()).toBeTruthy();
  });
});
